# SuiviSanté — Guide d'installation

Application web de suivi de poids et d'IMC (PHP / MySQL).

## 1. Prérequis

- Un serveur avec PHP 7.4+ et MySQL/MariaDB (ex : XAMPP, WAMP, MAMP, ou un hébergement classique)

## 2. Installation de la base de données

1. Crée la base et les tables en important le fichier `sql/schema.sql`
   (via phpMyAdmin, ou en ligne de commande : `mysql -u root -p < sql/schema.sql`)
2. Un compte administrateur est créé automatiquement :
   - E-mail : `admin@suivisante.fr`
   - Mot de passe : `admin123`
   - ⚠️ Pense à le changer une fois connecté (page "Profil")

## 3. Configuration

Ouvre `config/database.php` et adapte si besoin :
- `$hote` (généralement `localhost`)
- `$nom_base` (par défaut `suivisante`)
- `$utilisateur_bdd` et `$mot_de_passe_bdd` (tes identifiants MySQL)

## 4. Lancement

Place le dossier `suivisante/` dans le répertoire servi par ton serveur
(ex : `htdocs/` pour XAMPP), puis ouvre `http://localhost/suivisante/`.

## 5. Structure du projet

```
suivisante/
├── admin/              Espace administrateur (index.php)
├── assets/
│   ├── css/style.css   Style principal (sobre, 1 couleur d'accent)
│   └── js/graphique.js Affichage du graphique de poids (Chart.js)
├── config/
│   └── database.php    Connexion PDO à MySQL
├── includes/
│   ├── fonctions.php   Sécurité + calculs (IMC, conseils, progression)
│   ├── header.php      En-tête / navigation commune
│   └── footer.php      Pied de page commun
├── sql/
│   └── schema.sql       Script de création de la base de données
├── index.php            Accueil
├── inscription.php
├── connexion.php
├── deconnexion.php
├── onboarding.php       Complétion du profil (1re connexion)
├── tableau_de_bord.php
├── historique.php
└── profil.php
```

## 6. Notes techniques

- Mots de passe hachés avec `password_hash()` (bcrypt) — jamais stockés en clair
- Requêtes SQL préparées (PDO) partout — protection contre les injections SQL
- Toutes les entrées utilisateur affichées sont nettoyées avec `htmlspecialchars()` — protection contre les failles XSS
- Les conseils sont **entièrement programmés** (règles conditionnelles en PHP dans `genererConseil()`, dans `includes/fonctions.php`) — aucune IA externe
