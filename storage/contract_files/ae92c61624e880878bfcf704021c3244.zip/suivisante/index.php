<?php
require_once 'includes/fonctions.php';

// Si l'utilisateur est déjà connecté, on l'envoie directement sur son tableau de bord
if (estConnecte()) {
    header('Location: tableau_de_bord.php');
    exit;
}

$titrePage = 'Accueil';
require_once 'includes/header.php';
?>

<section class="section-heros">
    <h1>Suis ton poids, comprends ton corps, atteins ton objectif.</h1>
    <p>SuiviSanté t'aide à suivre ton IMC, ton poids et à recevoir des conseils
       personnalisés basés sur tes propres chiffres, jour après jour.</p>
    <a href="inscription.php" class="bouton bouton-principal">Créer un compte gratuitement</a>
</section>

<div class="grille-cartes">
    <div class="carte">
        <h3>📊 Tableau de bord clair</h3>
        <p style="color: var(--couleur-texte-doux); margin-bottom: 0;">
            Visualise ton IMC, ton poids et ta progression vers ton objectif en un coup d'œil.
        </p>
    </div>
    <div class="carte">
        <h3>📈 Historique complet</h3>
        <p style="color: var(--couleur-texte-doux); margin-bottom: 0;">
            Enregistre tes pesées et suis ton évolution grâce à un graphique simple.
        </p>
    </div>
    <div class="carte">
        <h3>💡 Conseils personnalisés</h3>
        <p style="color: var(--couleur-texte-doux); margin-bottom: 0;">
            Reçois des messages adaptés à ta situation réelle, calculés à partir de tes données.
        </p>
    </div>
</div>

<?php require_once 'includes/footer.php'; ?>
