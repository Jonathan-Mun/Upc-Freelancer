<?php
require_once 'includes/fonctions.php';
require_once 'config/database.php';
exigerConnexion();

$erreur = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $taille = (float) $_POST['taille'];
    $sexe = $_POST['sexe'];
    $age = (int) $_POST['age'];
    $objectif = $_POST['objectif'];
    $poidsActuel = (float) $_POST['poids_actuel'];
    $poidsCible = (float) $_POST['poids_cible'];
    $dateCible = !empty($_POST['date_cible']) ? $_POST['date_cible'] : null;

    if ($taille <= 0 || $age <= 0 || $poidsActuel <= 0 || $poidsCible <= 0) {
        $erreur = 'Merci de renseigner des valeurs valides.';
    } else {
        // Création du profil
        $insertionProfil = $pdo->prepare(
            'INSERT INTO profils (utilisateur_id, taille_cm, sexe, age, objectif, poids_cible, date_cible)
             VALUES (?, ?, ?, ?, ?, ?, ?)'
        );
        $insertionProfil->execute([
            $_SESSION['utilisateur_id'], $taille, $sexe, $age, $objectif, $poidsCible, $dateCible
        ]);

        // On enregistre aussi la première pesée (le poids actuel saisi)
        $insertionPesee = $pdo->prepare(
            'INSERT INTO pesees (utilisateur_id, poids, date_pesee) VALUES (?, ?, CURDATE())'
        );
        $insertionPesee->execute([$_SESSION['utilisateur_id'], $poidsActuel]);

        header('Location: tableau_de_bord.php');
        exit;
    }
}

$titrePage = 'Complète ton profil';
require_once 'includes/header.php';
?>

<div class="carte formulaire" style="max-width: 480px;">
    <h2>Complète ton profil</h2>
    <p style="color: var(--couleur-texte-doux); margin-top:-8px;">
        Ces informations nous permettent de calculer ton IMC et de personnaliser tes conseils.
    </p>

    <?php if ($erreur): ?>
        <div class="message message-erreur"><?= nettoyer($erreur) ?></div>
    <?php endif; ?>

    <form method="post" novalidate>
        <div class="champ">
            <label for="taille">Taille (en cm)</label>
            <input type="number" step="0.1" id="taille" name="taille" required>
        </div>
        <div class="champ">
            <label for="sexe">Sexe</label>
            <select id="sexe" name="sexe" required>
                <option value="homme">Homme</option>
                <option value="femme">Femme</option>
                <option value="autre">Autre</option>
            </select>
        </div>
        <div class="champ">
            <label for="age">Âge</label>
            <input type="number" id="age" name="age" required>
        </div>
        <div class="champ">
            <label for="poids_actuel">Poids actuel (en kg)</label>
            <input type="number" step="0.1" id="poids_actuel" name="poids_actuel" required>
        </div>
        <div class="champ">
            <label for="objectif">Ton objectif</label>
            <select id="objectif" name="objectif" required>
                <option value="perdre">Perdre du poids</option>
                <option value="prendre">Prendre du poids</option>
                <option value="maintenir">Maintenir mon poids</option>
            </select>
        </div>
        <div class="champ">
            <label for="poids_cible">Poids cible (en kg)</label>
            <input type="number" step="0.1" id="poids_cible" name="poids_cible" required>
        </div>
        <div class="champ">
            <label for="date_cible">Date visée (facultatif)</label>
            <input type="date" id="date_cible" name="date_cible">
        </div>
        <button type="submit" class="bouton bouton-principal" style="width:100%;">Valider mon profil</button>
    </form>
</div>

<?php require_once 'includes/footer.php'; ?>
