<?php
require_once 'includes/fonctions.php';
require_once 'config/database.php';
exigerConnexion();

$utilisateurId = $_SESSION['utilisateur_id'];
$erreur = '';
$succes = '';

// --- Ajout d'une nouvelle pesée ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['ajouter_pesee'])) {
    $poids = (float) $_POST['poids'];
    $date = $_POST['date_pesee'];

    if ($poids <= 0 || $poids > 400) {
        $erreur = 'Merci de saisir un poids valide.';
    } else {
        $insertion = $pdo->prepare('INSERT INTO pesees (utilisateur_id, poids, date_pesee) VALUES (?, ?, ?)');
        $insertion->execute([$utilisateurId, $poids, $date]);
        $succes = 'Pesée enregistrée avec succès.';
    }
}

// --- Suppression d'une pesée erronée ---
if (isset($_GET['supprimer'])) {
    $idASupprimer = (int) $_GET['supprimer'];

    // On vérifie que la pesée appartient bien à l'utilisateur connecté avant de la supprimer
    $suppression = $pdo->prepare('DELETE FROM pesees WHERE id = ? AND utilisateur_id = ?');
    $suppression->execute([$idASupprimer, $utilisateurId]);

    header('Location: historique.php');
    exit;
}

// Récupération de toutes les pesées (plus récentes en premier pour l'affichage en tableau)
$requetePesees = $pdo->prepare('SELECT * FROM pesees WHERE utilisateur_id = ? ORDER BY date_pesee DESC');
$requetePesees->execute([$utilisateurId]);
$peseesDesc = $requetePesees->fetchAll();

// Pour le graphique, on veut l'ordre chronologique (plus ancien en premier)
$peseesAsc = array_reverse($peseesDesc);
$datesGraphique = array_map(fn($p) => date('d/m/Y', strtotime($p['date_pesee'])), $peseesAsc);
$poidsGraphique = array_map(fn($p) => (float) $p['poids'], $peseesAsc);

$titrePage = 'Historique du poids';
require_once 'includes/header.php';
?>

<h2>Historique de mes pesées</h2>

<?php if ($erreur): ?>
    <div class="message message-erreur"><?= nettoyer($erreur) ?></div>
<?php endif; ?>
<?php if ($succes): ?>
    <div class="message message-succes"><?= nettoyer($succes) ?></div>
<?php endif; ?>

<div class="carte" style="margin-bottom:24px;">
    <h3>Ajouter une pesée</h3>
    <form method="post" style="display:flex; gap:16px; align-items:flex-end; flex-wrap:wrap;">
        <input type="hidden" name="ajouter_pesee" value="1">
        <div class="champ" style="margin-bottom:0;">
            <label for="poids">Poids (kg)</label>
            <input type="number" step="0.1" id="poids" name="poids" required>
        </div>
        <div class="champ" style="margin-bottom:0;">
            <label for="date_pesee">Date</label>
            <input type="date" id="date_pesee" name="date_pesee" value="<?= date('Y-m-d') ?>" required>
        </div>
        <button type="submit" class="bouton bouton-principal">Ajouter</button>
    </form>
</div>

<?php if (count($peseesAsc) >= 2): ?>
<div class="carte" style="margin-bottom:24px;">
    <h3>Évolution complète</h3>
    <canvas id="graphiquePoids" height="90"></canvas>
</div>
<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/4.4.1/chart.umd.min.js"></script>
<script>
    const dates = <?= json_encode($datesGraphique) ?>;
    const poids = <?= json_encode($poidsGraphique) ?>;
</script>
<script src="assets/js/graphique.js"></script>
<?php endif; ?>

<div class="carte">
    <h3>Toutes mes pesées</h3>
    <?php if (empty($peseesDesc)): ?>
        <p style="color: var(--couleur-texte-doux);">Aucune pesée enregistrée pour le moment.</p>
    <?php else: ?>
        <table>
            <thead>
                <tr>
                    <th>Date</th>
                    <th>Poids</th>
                    <th></th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($peseesDesc as $pesee): ?>
                    <tr>
                        <td><?= date('d/m/Y', strtotime($pesee['date_pesee'])) ?></td>
                        <td><?= $pesee['poids'] ?> kg</td>
                        <td>
                            <a href="historique.php?supprimer=<?= $pesee['id'] ?>"
                               class="bouton bouton-danger"
                               onclick="return confirm('Supprimer cette pesée ?');">
                               Supprimer
                            </a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php endif; ?>
</div>

<?php require_once 'includes/footer.php'; ?>
