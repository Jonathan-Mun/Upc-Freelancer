<?php
require_once 'includes/fonctions.php';
require_once 'config/database.php';

if (estConnecte()) {
    header('Location: tableau_de_bord.php');
    exit;
}

$erreur = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email']);
    $motDePasse = $_POST['mot_de_passe'];

    $requete = $pdo->prepare('SELECT * FROM utilisateurs WHERE email = ?');
    $requete->execute([$email]);
    $utilisateur = $requete->fetch();

    // password_verify() compare le mot de passe saisi au hash stocké
    if (!$utilisateur || !password_verify($motDePasse, $utilisateur['mot_de_passe'])) {
        $erreur = 'E-mail ou mot de passe incorrect.';
    } elseif (!$utilisateur['actif']) {
        $erreur = 'Ce compte a été désactivé. Contacte un administrateur.';
    } else {
        // Connexion réussie : on enregistre les infos utiles en session
        $_SESSION['utilisateur_id'] = $utilisateur['id'];
        $_SESSION['nom'] = $utilisateur['nom'];
        $_SESSION['role'] = $utilisateur['role'];

        if ($utilisateur['role'] === 'admin') {
            header('Location: admin/index.php');
        } else {
            // On vérifie si le profil (taille, objectif...) a déjà été rempli
            $requeteProfil = $pdo->prepare('SELECT id FROM profils WHERE utilisateur_id = ?');
            $requeteProfil->execute([$utilisateur['id']]);

            if ($requeteProfil->fetch()) {
                header('Location: tableau_de_bord.php');
            } else {
                header('Location: onboarding.php');
            }
        }
        exit;
    }
}

$titrePage = 'Connexion';
require_once 'includes/header.php';
?>

<div class="carte formulaire">
    <h2>Se connecter</h2>

    <?php if ($erreur): ?>
        <div class="message message-erreur"><?= nettoyer($erreur) ?></div>
    <?php endif; ?>

    <form method="post" novalidate>
        <div class="champ">
            <label for="email">Adresse e-mail</label>
            <input type="email" id="email" name="email" required>
        </div>
        <div class="champ">
            <label for="mot_de_passe">Mot de passe</label>
            <input type="password" id="mot_de_passe" name="mot_de_passe" required>
        </div>
        <button type="submit" class="bouton bouton-principal" style="width:100%;">Se connecter</button>
    </form>

    <p style="text-align:center; margin-top:18px; color: var(--couleur-texte-doux);">
        Pas encore de compte ? <a href="inscription.php">S'inscrire</a>
    </p>
</div>

<?php require_once 'includes/footer.php'; ?>
