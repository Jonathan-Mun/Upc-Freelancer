<?php
/**
 * Connexion à la base de données MySQL avec PDO
 * On utilise PDO avec des requêtes préparées partout dans le site
 * pour se protéger des injections SQL.
 */

// --- Paramètres de connexion (à adapter selon ton hébergement) ---
$hote      = 'localhost';
$nom_base  = 'suivisante';
$utilisateur_bdd = 'root';
$mot_de_passe_bdd = '';

try {
    // Connexion à la base avec PDO, en UTF-8
    $pdo = new PDO(
        "mysql:host=$hote;dbname=$nom_base;charset=utf8mb4",
        $utilisateur_bdd,
        $mot_de_passe_bdd
    );

    // On active les exceptions PDO pour attraper les erreurs proprement
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

} catch (PDOException $erreur) {
    // Si la connexion échoue, on arrête tout avec un message clair
    die('Erreur de connexion à la base de données : ' . $erreur->getMessage());
}
