<?php
require_once '../includes/fonctions.php';
require_once '../config/database.php';
exigerAdmin();

// --- Activer / désactiver un compte ---
if (isset($_GET['basculer_statut'])) {
    $id = (int) $_GET['basculer_statut'];
    $pdo->prepare('UPDATE utilisateurs SET actif = NOT actif WHERE id = ? AND role != "admin"')->execute([$id]);
    header('Location: index.php');
    exit;
}

// --- Suppression définitive d'un compte ---
if (isset($_GET['supprimer'])) {
    $id = (int) $_GET['supprimer'];
    // Les pesées et le profil liés sont supprimés automatiquement (ON DELETE CASCADE)
    $pdo->prepare('DELETE FROM utilisateurs WHERE id = ? AND role != "admin"')->execute([$id]);
    header('Location: index.php');
    exit;
}

// --- Statistiques globales ---
$nbUtilisateurs = $pdo->query('SELECT COUNT(*) FROM utilisateurs WHERE role = "utilisateur"')->fetchColumn();
$nbActifs = $pdo->query('SELECT COUNT(*) FROM utilisateurs WHERE role = "utilisateur" AND actif = 1')->fetchColumn();

$imcMoyen = $pdo->query(
    'SELECT AVG(p.poids / POWER(pr.taille_cm / 100, 2)) AS imc_moyen
     FROM profils pr
     JOIN utilisateurs u ON u.id = pr.utilisateur_id
     JOIN pesees p ON p.utilisateur_id = pr.utilisateur_id
     WHERE p.date_pesee = (SELECT MAX(date_pesee) FROM pesees WHERE utilisateur_id = pr.utilisateur_id)'
)->fetchColumn();

// --- Liste des utilisateurs (hors admins) ---
$utilisateurs = $pdo->query(
    'SELECT u.*, pr.objectif, pr.poids_cible
     FROM utilisateurs u
     LEFT JOIN profils pr ON pr.utilisateur_id = u.id
     WHERE u.role = "utilisateur"
     ORDER BY u.date_creation DESC'
)->fetchAll();

$racine = '../';
$titrePage = 'Administration';
require_once '../includes/header.php';
?>

<h2>Administration</h2>

<div class="grille-cartes">
    <div class="carte statistique">
        <div class="valeur"><?= $nbUtilisateurs ?></div>
        <div class="etiquette">Utilisateurs inscrits</div>
    </div>
    <div class="carte statistique">
        <div class="valeur"><?= $nbActifs ?></div>
        <div class="etiquette">Comptes actifs</div>
    </div>
    <div class="carte statistique">
        <div class="valeur"><?= $imcMoyen ? round($imcMoyen, 1) : '—' ?></div>
        <div class="etiquette">IMC moyen des utilisateurs</div>
    </div>
</div>

<div class="carte">
    <h3>Liste des utilisateurs</h3>
    <?php if (empty($utilisateurs)): ?>
        <p style="color: var(--couleur-texte-doux);">Aucun utilisateur inscrit pour le moment.</p>
    <?php else: ?>
        <table>
            <thead>
                <tr>
                    <th>Nom</th>
                    <th>E-mail</th>
                    <th>Objectif</th>
                    <th>Statut</th>
                    <th>Inscrit le</th>
                    <th></th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($utilisateurs as $u): ?>
                    <tr>
                        <td><?= nettoyer($u['nom']) ?></td>
                        <td><?= nettoyer($u['email']) ?></td>
                        <td><?= $u['objectif'] ? nettoyer($u['objectif']) : '—' ?></td>
                        <td>
                            <?php if ($u['actif']): ?>
                                <span class="badge badge-normal">Actif</span>
                            <?php else: ?>
                                <span class="badge badge-obesite">Désactivé</span>
                            <?php endif; ?>
                        </td>
                        <td><?= date('d/m/Y', strtotime($u['date_creation'])) ?></td>
                        <td style="white-space:nowrap;">
                            <a href="index.php?basculer_statut=<?= $u['id'] ?>" class="bouton bouton-secondaire" style="padding:6px 12px; font-size:0.85rem;">
                                <?= $u['actif'] ? 'Désactiver' : 'Réactiver' ?>
                            </a>
                            <a href="index.php?supprimer=<?= $u['id'] ?>" class="bouton bouton-danger"
                               onclick="return confirm('Supprimer définitivement ce compte et toutes ses données ?');">
                               Supprimer
                            </a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php endif; ?>
</div>

<?php require_once '../includes/footer.php'; ?>
