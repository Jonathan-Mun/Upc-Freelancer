<?php
require_once 'includes/fonctions.php';
require_once 'config/database.php';
exigerConnexion();

$utilisateurId = $_SESSION['utilisateur_id'];
$erreur = '';
$succes = '';

$requeteUtilisateur = $pdo->prepare('SELECT * FROM utilisateurs WHERE id = ?');
$requeteUtilisateur->execute([$utilisateurId]);
$utilisateur = $requeteUtilisateur->fetch();

$requeteProfil = $pdo->prepare('SELECT * FROM profils WHERE utilisateur_id = ?');
$requeteProfil->execute([$utilisateurId]);
$profil = $requeteProfil->fetch();

// --- Mise à jour du profil (infos physiques + objectif) ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['modifier_profil'])) {
    $taille = (float) $_POST['taille'];
    $sexe = $_POST['sexe'];
    $age = (int) $_POST['age'];
    $objectif = $_POST['objectif'];
    $poidsCible = (float) $_POST['poids_cible'];
    $dateCible = !empty($_POST['date_cible']) ? $_POST['date_cible'] : null;

    $mise_a_jour = $pdo->prepare(
        'UPDATE profils SET taille_cm=?, sexe=?, age=?, objectif=?, poids_cible=?, date_cible=? WHERE utilisateur_id=?'
    );
    $mise_a_jour->execute([$taille, $sexe, $age, $objectif, $poidsCible, $dateCible, $utilisateurId]);

    $succes = 'Profil mis à jour avec succès.';
    $profil = array_merge($profil, compact('taille', 'sexe', 'age', 'objectif', 'poidsCible', 'dateCible'));
}

// --- Changement de mot de passe ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['changer_mot_de_passe'])) {
    $ancien = $_POST['ancien_mot_de_passe'];
    $nouveau = $_POST['nouveau_mot_de_passe'];
    $confirmation = $_POST['confirmation_mot_de_passe'];

    if (!password_verify($ancien, $utilisateur['mot_de_passe'])) {
        $erreur = 'Ton mot de passe actuel est incorrect.';
    } elseif (strlen($nouveau) < 6) {
        $erreur = 'Le nouveau mot de passe doit contenir au moins 6 caractères.';
    } elseif ($nouveau !== $confirmation) {
        $erreur = 'Les deux mots de passe ne correspondent pas.';
    } else {
        $nouveauHache = password_hash($nouveau, PASSWORD_BCRYPT);
        $mise_a_jour = $pdo->prepare('UPDATE utilisateurs SET mot_de_passe=? WHERE id=?');
        $mise_a_jour->execute([$nouveauHache, $utilisateurId]);
        $succes = 'Mot de passe modifié avec succès.';
    }
}

$titrePage = 'Mon profil';
require_once 'includes/header.php';
?>

<h2>Mon profil</h2>

<?php if ($erreur): ?>
    <div class="message message-erreur"><?= nettoyer($erreur) ?></div>
<?php endif; ?>
<?php if ($succes): ?>
    <div class="message message-succes"><?= nettoyer($succes) ?></div>
<?php endif; ?>

<div class="carte" style="margin-bottom:24px; max-width:480px;">
    <h3>Informations personnelles</h3>
    <form method="post">
        <input type="hidden" name="modifier_profil" value="1">
        <div class="champ">
            <label for="taille">Taille (cm)</label>
            <input type="number" step="0.1" id="taille" name="taille" value="<?= $profil['taille_cm'] ?>" required>
        </div>
        <div class="champ">
            <label for="sexe">Sexe</label>
            <select id="sexe" name="sexe">
                <option value="homme" <?= $profil['sexe'] === 'homme' ? 'selected' : '' ?>>Homme</option>
                <option value="femme" <?= $profil['sexe'] === 'femme' ? 'selected' : '' ?>>Femme</option>
                <option value="autre" <?= $profil['sexe'] === 'autre' ? 'selected' : '' ?>>Autre</option>
            </select>
        </div>
        <div class="champ">
            <label for="age">Âge</label>
            <input type="number" id="age" name="age" value="<?= $profil['age'] ?>" required>
        </div>
        <div class="champ">
            <label for="objectif">Objectif</label>
            <select id="objectif" name="objectif">
                <option value="perdre" <?= $profil['objectif'] === 'perdre' ? 'selected' : '' ?>>Perdre du poids</option>
                <option value="prendre" <?= $profil['objectif'] === 'prendre' ? 'selected' : '' ?>>Prendre du poids</option>
                <option value="maintenir" <?= $profil['objectif'] === 'maintenir' ? 'selected' : '' ?>>Maintenir mon poids</option>
            </select>
        </div>
        <div class="champ">
            <label for="poids_cible">Poids cible (kg)</label>
            <input type="number" step="0.1" id="poids_cible" name="poids_cible" value="<?= $profil['poids_cible'] ?>" required>
        </div>
        <div class="champ">
            <label for="date_cible">Date visée</label>
            <input type="date" id="date_cible" name="date_cible" value="<?= $profil['date_cible'] ?>">
        </div>
        <button type="submit" class="bouton bouton-principal">Enregistrer</button>
    </form>
</div>

<div class="carte" style="max-width:480px;">
    <h3>Changer mon mot de passe</h3>
    <form method="post">
        <input type="hidden" name="changer_mot_de_passe" value="1">
        <div class="champ">
            <label for="ancien_mot_de_passe">Mot de passe actuel</label>
            <input type="password" id="ancien_mot_de_passe" name="ancien_mot_de_passe" required>
        </div>
        <div class="champ">
            <label for="nouveau_mot_de_passe">Nouveau mot de passe</label>
            <input type="password" id="nouveau_mot_de_passe" name="nouveau_mot_de_passe" minlength="6" required>
        </div>
        <div class="champ">
            <label for="confirmation_mot_de_passe">Confirmer le nouveau mot de passe</label>
            <input type="password" id="confirmation_mot_de_passe" name="confirmation_mot_de_passe" minlength="6" required>
        </div>
        <button type="submit" class="bouton bouton-secondaire">Changer le mot de passe</button>
    </form>
</div>

<?php require_once 'includes/footer.php'; ?>
