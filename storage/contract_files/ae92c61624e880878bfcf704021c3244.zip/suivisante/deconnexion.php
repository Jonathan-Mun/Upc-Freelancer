<?php
require_once 'includes/fonctions.php';

// On vide et détruit la session pour déconnecter l'utilisateur
$_SESSION = [];
session_destroy();

header('Location: index.php');
exit;
