<?php
require_once 'includes/fonctions.php';
require_once 'config/database.php';
exigerConnexion();

$utilisateurId = $_SESSION['utilisateur_id'];

// Récupération du profil
$requeteProfil = $pdo->prepare('SELECT * FROM profils WHERE utilisateur_id = ?');
$requeteProfil->execute([$utilisateurId]);
$profil = $requeteProfil->fetch();

// Si le profil n'existe pas encore, on redirige vers l'onboarding
if (!$profil) {
    header('Location: onboarding.php');
    exit;
}

// Récupération de toutes les pesées, triées de la plus ancienne à la plus récente
$requetePesees = $pdo->prepare('SELECT * FROM pesees WHERE utilisateur_id = ? ORDER BY date_pesee ASC');
$requetePesees->execute([$utilisateurId]);
$pesees = $requetePesees->fetchAll();

$poidsDepart = (float) $pesees[0]['poids'];
$poidsActuel = (float) $pesees[count($pesees) - 1]['poids'];
$variation = count($pesees) > 1 ? round($poidsActuel - (float) $pesees[count($pesees) - 2]['poids'], 1) : 0;

// On ne garde que les pesées des 14 derniers jours pour la tendance
$peseesRecentes = array_filter($pesees, function ($p) {
    return strtotime($p['date_pesee']) >= strtotime('-14 days');
});
$peseesRecentes = array_values($peseesRecentes);

$imc = calculerIMC($poidsActuel, $profil['taille_cm']);
$categorie = categorieIMC($imc);
$classeBadge = [
    'Maigreur' => 'badge-maigreur',
    'Corpulence normale' => 'badge-normal',
    'Surpoids' => 'badge-surpoids',
    'Obésité' => 'badge-obesite',
][$categorie];

$tendance = calculerTendance(count($peseesRecentes) >= 2 ? $peseesRecentes : $pesees);
$ecartCible = abs($poidsActuel - (float) $profil['poids_cible']);
$conseil = genererConseil($imc, $tendance, $profil['objectif'], $ecartCible);
$progression = calculerProgression($poidsDepart, $poidsActuel, (float) $profil['poids_cible']);

// Données pour le mini-graphique (30 derniers jours max)
$peseesGraphique = array_slice($pesees, -30);
$datesGraphique = array_map(fn($p) => date('d/m', strtotime($p['date_pesee'])), $peseesGraphique);
$poidsGraphique = array_map(fn($p) => (float) $p['poids'], $peseesGraphique);

$titrePage = 'Tableau de bord';
require_once 'includes/header.php';
?>

<h2>Bonjour <?= nettoyer($_SESSION['nom']) ?> 👋</h2>

<div class="bloc-conseil">
    💡 <?= nettoyer($conseil) ?>
</div>

<div class="grille-cartes">
    <div class="carte statistique">
        <div class="valeur"><?= $poidsActuel ?> kg</div>
        <div class="etiquette">
            Poids actuel
            <?php if ($variation != 0): ?>
                (<?= $variation > 0 ? '+' : '' ?><?= $variation ?> kg)
            <?php endif; ?>
        </div>
    </div>
    <div class="carte statistique">
        <div class="valeur"><?= $imc ?></div>
        <div class="etiquette">
            IMC — <span class="badge <?= $classeBadge ?>"><?= $categorie ?></span>
        </div>
    </div>
    <div class="carte statistique">
        <div class="valeur"><?= $profil['poids_cible'] ?> kg</div>
        <div class="etiquette">Objectif (<?= $profil['objectif'] ?>)</div>
    </div>
</div>

<div class="carte" style="margin-bottom:20px;">
    <h3>Progression vers ton objectif</h3>
    <div class="barre-progression-fond">
        <div class="barre-progression-remplissage" style="width: <?= $progression ?>%;"></div>
    </div>
    <p style="color: var(--couleur-texte-doux); margin-bottom:0; margin-top:8px;">
        <?= $progression ?>% de ton objectif atteint
    </p>
</div>

<div class="carte" style="margin-bottom:32px;">
    <h3>Évolution récente</h3>
    <canvas id="graphiquePoids" height="90"></canvas>
</div>

<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/4.4.1/chart.umd.min.js"></script>
<script>
    // Les dates et poids sont injectés depuis PHP au format JSON
    const dates = <?= json_encode($datesGraphique) ?>;
    const poids = <?= json_encode($poidsGraphique) ?>;
</script>
<script src="assets/js/graphique.js"></script>

<?php require_once 'includes/footer.php'; ?>
