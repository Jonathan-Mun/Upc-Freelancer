// Affiche un graphique en ligne de l'évolution du poids
// Les variables "dates" et "poids" sont définies juste avant ce script (voir tableau_de_bord.php / historique.php)

document.addEventListener('DOMContentLoaded', function () {
    const canvas = document.getElementById('graphiquePoids');
    if (!canvas) return; // sécurité si le canvas n'existe pas sur la page

    new Chart(canvas, {
        type: 'line',
        data: {
            labels: dates,
            datasets: [{
                label: 'Poids (kg)',
                data: poids,
                borderColor: '#2F9E8F',
                backgroundColor: 'rgba(47, 158, 143, 0.08)',
                borderWidth: 2,
                pointRadius: 3,
                pointBackgroundColor: '#2F9E8F',
                tension: 0.3,
                fill: true
            }]
        },
        options: {
            responsive: true,
            plugins: {
                legend: { display: false }
            },
            scales: {
                y: {
                    grid: { color: '#F0F0F0' }
                },
                x: {
                    grid: { display: false }
                }
            }
        }
    });
});
