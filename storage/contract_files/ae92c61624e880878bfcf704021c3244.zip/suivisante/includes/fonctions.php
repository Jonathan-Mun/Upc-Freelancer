<?php
/**
 * Fonctions utilitaires du site Suivisante
 * Regroupe : sécurité des sessions, calculs santé (IMC, tendance, progression)
 * et génération des conseils personnalisés.
 */

// On démarre la session une seule fois, ici
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

/**
 * Vérifie si un utilisateur est connecté.
 */
function estConnecte() {
    return isset($_SESSION['utilisateur_id']);
}

/**
 * Bloque l'accès à la page si l'utilisateur n'est pas connecté.
 */
function exigerConnexion() {
    if (!estConnecte()) {
        header('Location: connexion.php');
        exit;
    }
}

/**
 * Bloque l'accès à la page si l'utilisateur n'est pas administrateur.
 */
function exigerAdmin() {
    exigerConnexion();
    if ($_SESSION['role'] !== 'admin') {
        header('Location: tableau_de_bord.php');
        exit;
    }
}

/**
 * Nettoie une chaîne de caractères saisie par l'utilisateur
 * (évite les failles XSS quand on affiche du texte saisi).
 */
function nettoyer($texte) {
    return htmlspecialchars(trim($texte), ENT_QUOTES, 'UTF-8');
}

/**
 * Calcule l'IMC (Indice de Masse Corporelle).
 * Formule : poids (kg) / (taille (m) ^ 2)
 */
function calculerIMC($poidsKg, $tailleCm) {
    $tailleM = $tailleCm / 100;
    if ($tailleM <= 0) {
        return 0;
    }
    return round($poidsKg / ($tailleM * $tailleM), 1);
}

/**
 * Retourne la catégorie de l'IMC selon les seuils officiels (OMS).
 */
function categorieIMC($imc) {
    if ($imc < 18.5) {
        return 'Maigreur';
    } elseif ($imc < 25) {
        return 'Corpulence normale';
    } elseif ($imc < 30) {
        return 'Surpoids';
    } else {
        return 'Obésité';
    }
}

/**
 * Détermine la tendance récente du poids à partir d'une liste de pesées
 * (triées de la plus ancienne à la plus récente).
 * Compare la moyenne des 2 dernières semaines à la moyenne des 2 semaines précédentes.
 *
 * Retourne : 'baisse', 'hausse' ou 'stable'
 */
function calculerTendance($pesees) {
    if (count($pesees) < 2) {
        return 'stable'; // pas assez de données pour juger
    }

    $premierPoids = (float) $pesees[0]['poids'];
    $dernierPoids = (float) $pesees[count($pesees) - 1]['poids'];
    $ecart = $dernierPoids - $premierPoids;

    // Seuil de 0.5 kg pour considérer que le poids a réellement bougé
    if ($ecart <= -0.5) {
        return 'baisse';
    } elseif ($ecart >= 0.5) {
        return 'hausse';
    } else {
        return 'stable';
    }
}

/**
 * Génère un conseil personnalisé et 100% programmé (aucune IA externe),
 * basé uniquement sur des règles simples et les chiffres de l'utilisateur.
 *
 * @param float  $imc        IMC actuel
 * @param string $tendance   'baisse', 'hausse' ou 'stable'
 * @param string $objectif   'perdre', 'prendre' ou 'maintenir'
 * @param float  $ecartCible écart absolu entre poids actuel et poids cible (en kg)
 */
function genererConseil($imc, $tendance, $objectif, $ecartCible) {

    // 1. Objectif atteint (moins de 1kg d'écart avec la cible)
    if ($ecartCible < 1) {
        return "Félicitations, tu as atteint ton objectif de poids ! 🎉 Continue à bien t'alimenter pour le maintenir.";
    }

    // 2. Cas où l'IMC est très élevé : priorité à la santé
    if ($imc >= 30) {
        return "Ton IMC actuel est élevé. Un accompagnement médical ou nutritionnel en complément du suivi pourrait t'aider.";
    }

    // 3. Cas selon l'objectif "perdre du poids"
    if ($objectif === 'perdre') {
        if ($tendance === 'baisse') {
            return "Bonne dynamique ! Ton poids diminue régulièrement, tu es sur la bonne voie vers ton objectif.";
        } elseif ($tendance === 'stable') {
            return "Ton poids stagne depuis quelques temps. Essaie d'ajuster légèrement ton alimentation ou ton activité physique.";
        } else { // hausse
            return "Ton poids a tendance à augmenter alors que ton objectif est d'en perdre. Reste vigilant sur les prochains jours.";
        }
    }

    // 4. Cas selon l'objectif "prendre du poids"
    if ($objectif === 'prendre') {
        if ($tendance === 'hausse') {
            return "Bonne progression ! Ton poids augmente régulièrement vers ton objectif.";
        } elseif ($tendance === 'stable') {
            return "Ton poids stagne. Pense à augmenter légèrement tes apports caloriques pour progresser vers ton objectif.";
        } else { // baisse
            return "Ton poids a tendance à diminuer alors que ton objectif est d'en prendre. Vérifie tes apports alimentaires.";
        }
    }

    // 5. Cas "maintenir"
    if ($objectif === 'maintenir') {
        if ($tendance === 'stable') {
            return "Bravo, ton poids est stable et ton IMC est dans une bonne fourchette. Continue ainsi !";
        } else {
            return "Ton poids a légèrement varié récemment. Rien d'inquiétant, garde un œil sur la régularité de tes habitudes.";
        }
    }

    // 6. Message par défaut (sécurité, ne devrait pas arriver)
    return "Continue à enregistrer tes pesées régulièrement pour obtenir un suivi précis.";
}

/**
 * Calcule la progression (en %) vers l'objectif de poids.
 * 0% = poids de départ, 100% = poids cible atteint ou dépassé.
 */
function calculerProgression($poidsDepart, $poidsActuel, $poidsCible) {
    if ($poidsDepart == $poidsCible) {
        return 100;
    }
    $progression = (($poidsDepart - $poidsActuel) / ($poidsDepart - $poidsCible)) * 100;

    // On borne la progression entre 0 et 100 pour l'affichage
    return max(0, min(100, round($progression)));
}
