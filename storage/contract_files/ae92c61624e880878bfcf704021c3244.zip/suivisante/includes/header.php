<?php
// $racine permet aux pages placées dans un sous-dossier (ex: admin/) de generer
// des liens et chemins corrects. Par defaut on est a la racine du site.
if (!isset($racine)) {
    $racine = '';
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= isset($titrePage) ? nettoyer($titrePage) . ' - Suivisante' : 'Suivisante' ?></title>
    <link rel="stylesheet" href="<?= $racine ?>assets/css/style.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
</head>
<body>

<header class="entete">
    <div class="barre-nav">
        <a href="<?= $racine ?><?= estConnecte() ? 'tableau_de_bord.php' : 'index.php' ?>" class="logo">Suivi<span>Santé</span></a>

        <ul class="nav-liens">
            <?php if (estConnecte()): ?>
                <li><a href="<?= $racine ?>tableau_de_bord.php">Tableau de bord</a></li>
                <li><a href="<?= $racine ?>historique.php">Historique</a></li>
                <li><a href="<?= $racine ?>profil.php">Profil</a></li>
                <?php if ($_SESSION['role'] === 'admin'): ?>
                    <li><a href="<?= $racine ?>admin/index.php">Administration</a></li>
                <?php endif; ?>
                <li><a href="<?= $racine ?>deconnexion.php">Déconnexion</a></li>
            <?php else: ?>
                <li><a href="<?= $racine ?>connexion.php">Connexion</a></li>
                <li><a href="<?= $racine ?>inscription.php" class="bouton bouton-principal">Créer un compte</a></li>
            <?php endif; ?>
        </ul>
    </div>
</header>

<main class="conteneur">
