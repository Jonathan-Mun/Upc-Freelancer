</main>

<footer class="pied-de-page">
    &copy; <?= date('Y') ?> SuiviSanté — Ton compagnon de suivi de poids au quotidien.
</footer>

</body>
</html>
