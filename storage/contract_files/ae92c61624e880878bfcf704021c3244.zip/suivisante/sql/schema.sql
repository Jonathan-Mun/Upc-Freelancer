-- ============================================================
-- SUIVISANTE - Script de création de la base de données
-- ============================================================

CREATE DATABASE IF NOT EXISTS suivisante CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE suivisante;

-- Table des utilisateurs (comptes)
CREATE TABLE utilisateurs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nom VARCHAR(100) NOT NULL,
    email VARCHAR(150) NOT NULL UNIQUE,
    mot_de_passe VARCHAR(255) NOT NULL, -- mot de passe haché (password_hash)
    role ENUM('utilisateur', 'admin') NOT NULL DEFAULT 'utilisateur',
    date_creation DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    actif TINYINT(1) NOT NULL DEFAULT 1 -- permet à l'admin de désactiver un compte
);

-- Table des profils (infos physiques + objectif de chaque utilisateur)
CREATE TABLE profils (
    id INT AUTO_INCREMENT PRIMARY KEY,
    utilisateur_id INT NOT NULL UNIQUE,
    taille_cm DECIMAL(5,1) NOT NULL,      -- ex : 175.5
    sexe ENUM('homme', 'femme', 'autre') NOT NULL,
    age INT NOT NULL,
    objectif ENUM('perdre', 'prendre', 'maintenir') NOT NULL,
    poids_cible DECIMAL(5,1) NOT NULL,    -- poids que l'utilisateur veut atteindre
    date_cible DATE NULL,                 -- date visée pour atteindre l'objectif (facultatif)
    FOREIGN KEY (utilisateur_id) REFERENCES utilisateurs(id) ON DELETE CASCADE
);

-- Table des pesées (historique du poids)
CREATE TABLE pesees (
    id INT AUTO_INCREMENT PRIMARY KEY,
    utilisateur_id INT NOT NULL,
    poids DECIMAL(5,1) NOT NULL,          -- poids en kg
    date_pesee DATE NOT NULL,
    FOREIGN KEY (utilisateur_id) REFERENCES utilisateurs(id) ON DELETE CASCADE
);

-- Compte admin par défaut (email : admin@suivisante.fr / mot de passe : admin123)
-- Le mot de passe est haché avec l'algorithme bcrypt (compatible password_verify() de PHP)
-- ⚠️ Pense à changer ce mot de passe une fois connecté !
INSERT INTO utilisateurs (nom, email, mot_de_passe, role)
VALUES ('Administrateur', 'admin@suivisante.fr', '$2b$12$Vjxp8KheFMl1I0Z6RhRLbeG9TA/1Etfrukw6ZcRIsMbUYaHrmSJ/G', 'admin');
