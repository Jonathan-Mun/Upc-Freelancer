<?php
require_once 'includes/fonctions.php';
require_once 'config/database.php';

if (estConnecte()) {
    header('Location: tableau_de_bord.php');
    exit;
}

$erreur = '';

// Traitement du formulaire quand il est envoyé
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $nom = nettoyer($_POST['nom']);
    $email = filter_var(trim($_POST['email']), FILTER_VALIDATE_EMAIL);
    $motDePasse = $_POST['mot_de_passe'];
    $confirmation = $_POST['confirmation'];

    if (!$email) {
        $erreur = 'Adresse e-mail invalide.';
    } elseif (strlen($motDePasse) < 6) {
        $erreur = 'Le mot de passe doit contenir au moins 6 caractères.';
    } elseif ($motDePasse !== $confirmation) {
        $erreur = 'Les deux mots de passe ne correspondent pas.';
    } else {
        // On vérifie que l'e-mail n'est pas déjà utilisé
        $requete = $pdo->prepare('SELECT id FROM utilisateurs WHERE email = ?');
        $requete->execute([$email]);

        if ($requete->fetch()) {
            $erreur = 'Cette adresse e-mail est déjà utilisée.';
        } else {
            // On hache le mot de passe avant de l'enregistrer (jamais en clair !)
            $motDePasseHache = password_hash($motDePasse, PASSWORD_BCRYPT);

            $insertion = $pdo->prepare(
                'INSERT INTO utilisateurs (nom, email, mot_de_passe, role) VALUES (?, ?, ?, "utilisateur")'
            );
            $insertion->execute([$nom, $email, $motDePasseHache]);

            $nouvelUtilisateurId = $pdo->lastInsertId();

            // Connexion automatique de l'utilisateur après inscription
            $_SESSION['utilisateur_id'] = $nouvelUtilisateurId;
            $_SESSION['nom'] = $nom;
            $_SESSION['role'] = 'utilisateur';

            // On l'envoie compléter son profil (taille, objectif...)
            header('Location: onboarding.php');
            exit;
        }
    }
}

$titrePage = 'Créer un compte';
require_once 'includes/header.php';
?>

<div class="carte formulaire">
    <h2>Créer un compte</h2>

    <?php if ($erreur): ?>
        <div class="message message-erreur"><?= nettoyer($erreur) ?></div>
    <?php endif; ?>

    <form method="post" novalidate>
        <div class="champ">
            <label for="nom">Nom</label>
            <input type="text" id="nom" name="nom" required>
        </div>
        <div class="champ">
            <label for="email">Adresse e-mail</label>
            <input type="email" id="email" name="email" required>
        </div>
        <div class="champ">
            <label for="mot_de_passe">Mot de passe (6 caractères min.)</label>
            <input type="password" id="mot_de_passe" name="mot_de_passe" minlength="6" required>
        </div>
        <div class="champ">
            <label for="confirmation">Confirmer le mot de passe</label>
            <input type="password" id="confirmation" name="confirmation" minlength="6" required>
        </div>
        <button type="submit" class="bouton bouton-principal" style="width:100%;">Créer mon compte</button>
    </form>

    <p style="text-align:center; margin-top:18px; color: var(--couleur-texte-doux);">
        Déjà un compte ? <a href="connexion.php">Se connecter</a>
    </p>
</div>

<?php require_once 'includes/footer.php'; ?>
